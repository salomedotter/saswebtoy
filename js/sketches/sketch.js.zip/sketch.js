let freq;
let amp;
let waveLength;

var mic;


const RECT = {
  width: 400,
  height: 900,
  x: 100,
  x1: 0, //parce que c'est ce qui va changer
  x2: undefined,
  offsetx: 0,
  y: 0,
  selected: false,
}


function setup() {
  createCanvas(windowWidth, windowHeight);
  mic = new p5.AudioIn();

  const micButton = createButton('Enable Microphone');
  micButton.center();

  micButton.mouseClicked(() => {
    getAudioContext().resume().then(() => {
      mic.start();
      micButton.hide();
      console.log('Recording Audio');
    }).catch((e) => { });
  });

  RECT.x2 = RECT.x + RECT.width;
  RECT.x1 = RECT.x;

}
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function drawRectLogo() {

  push();
  stroke(255, 0, 255);
  strokeWeight(10);
  noFill();
  translate(RECT.x, RECT.y);
  rect(0, 0, RECT.width, RECT.height);


  pop();
}

function mousePressed() {

  RECT.x1 = RECT.x;
  RECT.x2 = RECT.x + RECT.width;
  let y1 = RECT.y;
  let y2 = RECT.y + RECT.height;

  RECT.offsetx = RECT.x - mouseX;

  // let coteDroit = 
  if (mouseX > RECT.x1 && mouseX < RECT.x2) {
    if (mouseY > y1 && mouseY < y2) {
      RECT.selected = true;
    }
  }
}

function mouseReleased() {
  RECT.selected = false;
}

function mouseDragged() {

  if (RECT.selected) {
    RECT.x = mouseX + RECT.offsetx;
    RECT.x1 = RECT.x;
    RECT.x2 = RECT.x + RECT.width;
  }

  // RECT.x = mouseX;
}


function draw() {

  var vol = mic.getLevel();
  console.log(vol);
  background(255);
  stroke(4);
  noFill();


  drawRectLogo();



  //freq = map(mouseX, 0, width, 1, 0); //nombre d'ondes
  freq = map(mouseX, 0, width, 1, 0); //nombre d'ondes
  //amp = map(mouseY, 0, height, 100, 0);
  amp = map(vol * 200, 0, height, 100, 0);
  waveLength = width / (freq * width) * TWO_PI; //i dont know how i found that haha


  translate(0, height / 5);
  push();
  stroke(255, 0, 255);
  line(0, 0, width, 0);
  pop();
  drawSine(amp, freq);

  //premiere shape
  fill(255, 0, 0)
  beginShape();
  for (var x = RECT.x; x < RECT.x + RECT.width; x++) {
    /* const angle = x * freq;
    const y = sin(angle)*amp;
    vertex(x, y); */
    const y = amp * sin(TWO_PI / waveLength * x)
    vertex(x, y);

  }
  /* var nSegment = (x-waveLength/4)/(waveLength/2);
  var direction = Math.floor(nSegment)%2;

  var partieVirgule = nSegment - Math.floor(nSegment);
  var y = 0;
  if(direction == 1) {

    y = partieVirgule * amp + height/5 - amp/2;
  }
  else {
    y = -partieVirgule * amp + height/5 + amp/2;
  } */


  for (var x = RECT.x + RECT.width; x > RECT.x; x--) {
    const y = 2 * amp / PI * asin(sin(TWO_PI / waveLength * x)) + height / 5
    vertex(x, y);
  }

  //vertex(x, y);
  //vertex(RECT.x, y)

  endShape();
  noFill()

  translate(0, height / 5);
  line(0, 0, width, 0);

  drawTriangle(amp, freq, waveLength);

  //deuxieme shape
  fill(255, 0, 255)
  beginShape();
  for (var x = RECT.x; x < RECT.x + RECT.width; x++) {

    const y = 2 * amp / PI * asin(sin(TWO_PI / waveLength * x))
    vertex(x, y);


  }



  for (var x = RECT.x + RECT.width; x > RECT.x; x--) {
    var nSegment = (x) / (waveLength / 2);
    var direction = Math.floor(nSegment) % 2;
    if (direction == 0) { y = amp + height / 5 }

    else {

      y = -amp + height / 5


    }

    vertex(x, y);
  }

  endShape();
  noFill()




  translate(0, height / 5);
  line(0, 0, width, 0);
  drawSquare(amp, freq, waveLength);

  //3 shape
  fill(0, 255, 255)
  beginShape();
  for (var x = RECT.x; x < RECT.x + RECT.width; x++) { 
    var nSegment = (x) / (waveLength / 2);
    var direction = Math.floor(nSegment) % 2;
    if (direction == 0) { y = amp  }

    else {

      y = -amp 


       } 

      vertex(x, y);
  }



  for (var x = RECT.x + RECT.width; x > RECT.x; x--) {
    var nSegment = (x) / (waveLength);
    var y = ((nSegment - Math.floor (nSegment)) - 0.5 ) * 2 * -amp + height/5 

      vertex(x, y);
    }

    endShape();
    noFill()





    translate(0, height / 5);
    line(0, 0, width, 0);
    drawSawtooth(amp, freq, waveLength);









  }

  function drawSawtooth(amp, freq, waveLength) {
    beginShape();
    for (let x = 0; x <= width; x += waveLength) {
      vertex(x, amp);
      vertex(x + waveLength, -amp);
    }
    endShape();
  }

  // function getSawtooth(amp, freq, waveLength, x) {
  //   return 
  // }

  function drawTriangle(amp, freq, waveLength) {

    let HWaveLength = waveLength / 2; //hal wave length
    beginShape();

    let way = -1; //up or down
    for (let x = -HWaveLength / 2; x <= width + HWaveLength; x += HWaveLength) {
      vertex(x, amp * way);
      way *= -1;
    }

    endShape();
  }

  function drawSquare(amp, freq, waveLength) {

    let HWaveLength = waveLength / 2;
    beginShape();

    for (let x = 0; x <= width; x += waveLength) {
      vertex(x, amp);
      vertex(x + HWaveLength, amp);
      vertex(x + HWaveLength, -amp);
      vertex(x + waveLength, -amp);
    }

    endShape();
  }

  function drawSine(amp, freq) {
    //sine
    beginShape();
    for (let x = 0; x <= width; x++) {

      const angle = x * freq;
      const y = sin(angle) * amp;

      vertex(x, y);
    }
    endShape();
  }